package com.cg.dto;

public class UserDTO {
    private Long id;
    private String username;
}