package com.cg.config;

import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;


public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }
//	@Bean
//    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
//        http
//            .csrf().disable() // Disable CSRF for easier testing
//            .authorizeHttpRequests()
//            .requestMatchers("/register", "/addCourse","/users/**").permitAll() // Allow unauthenticated access
//            .requestMatchers("/login").permitAll() // Allow unauthenticated access
//            .requestMatchers("/users/{id}").permitAll() // Allow unauthenticated access
//
//           // .requestMatchers("/users").permitAll() // Allow unauthenticated access
//
//            .anyRequest().authenticated() // Secure other endpoints
//            .and()
//            
//            .httpBasic(); // Optional: Enables basic authentication
//
//        return http.build();
//    }
    
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .csrf().disable() // Disable CSRF for simplicity; enable in production if necessary
            .authorizeHttpRequests(auth -> auth
                .requestMatchers("/api/courses/**").authenticated() // Protect Course APIs
                .anyRequest().permitAll() // Allow other endpoints
            )
            .httpBasic(); // Use Basic Authentication

        return http.build();
    }

	/*
	 * @Bean public UserDetailsService userDetailsService() { UserDetails user =
	 * User.builder() .username("user") .password("{noop}password") // {noop}
	 * disables password encoding for simplicity .roles("USER") .build();
	 * 
	 * UserDetails admin = User.builder() .username("admin")
	 * .password("{noop}admin123") .roles("ADMIN")8 .build();
	 * 
	 * return new InMemoryUserDetailsManager(user, admin); }
	 */


}
