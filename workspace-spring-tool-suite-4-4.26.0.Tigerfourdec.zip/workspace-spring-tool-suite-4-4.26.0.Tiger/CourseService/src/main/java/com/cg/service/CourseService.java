package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.client.UserServiceClient;
import com.cg.dto.CourseDTO;
import com.cg.dto.UserDTO;
import com.cg.entity.Course;
import com.cg.exception.ResourceNotFoundException;
import com.cg.repository.CourseRepository;

import feign.FeignException;
import lombok.RequiredArgsConstructor;

@Service

public class CourseService {
	 @Autowired
	    private CourseRepository courseRepository;
//    public Course createCourse(CourseDTO courseDTO) {
//        // Validate user ID using Feign client
//        UserDTO user = userServiceClient.getUserById(courseDTO.getUserId());
//        
//        if (user == null || user.getStatus() != 1) {
//        	if (user == null || user.getStatus() != 1) {
//                throw new IllegalArgumentException("Invalid or inactive user ID");
//            }
//
//        	
//        String instructor = x   	ser.getUsername();
//
//        // Map CourseDTO to Course entity
//        Course course = new Course();
//        course.setTitle(courseDTO.getTitle());
//        course.setDescription(courseDTO.getDescription());
////        course.setInstructor(courseDTO.getInstructor());
//        course.setInstructor(instructor);
//
//        course.setStatus(courseDTO.getStatus());
//        course.setUserId(courseDTO.getUserId());
//
//        // Save course to the database
//        return courseRepository.save(course);
//    } 
    
    /*public Course createCourse(CourseDTO courseDTO) {
        // Validate user ID using Feign client
    	

    	UserDTO user;
        try {
            user = userServiceClient.getUserById(courseDTO.getUserId());
        } catch (FeignException.NotFound e) {
            throw new IllegalArgumentException("User not found for ID: " + courseDTO.getUserId());
        }

        if (user.getStatus() != 1) {
            throw new IllegalArgumentException("Inactive user ID: " + courseDTO.getUserId());
        }
    	
//    	User user = userRepository.findById(userId)
//    		    .orElseThrow(() -> new IllegalArgumentException("User not found for ID: " + userId));


        // Populate the instructor field using the username from UserService
        String instructor = user.getUsername();

        // Map CourseDTO to Course entity
        Course course = new Course();
        course.setTitle(courseDTO.getTitle());          // Set title from request
        course.setDescription(courseDTO.getDescription()); // Set description from request
        course.setStatus(1);        // Set status from request
        course.setUserId(courseDTO.getUserId());        // Set userId from request
//        course.setInstructor(instructor);              // Set instructor from UserService
        course.setInstructor("Suvarna");  // Assuming the UserDTO has the username field

        
        // Save course to the database
        return courseRepository.save(course);
    }

    public CourseService(CourseRepository courseRepository, UserServiceClient userServiceClient) {
        this.courseRepository = courseRepository;
        this.userServiceClient = userServiceClient;
    }
//    public CourseService(CourseRepository courseRepository) {
//        this.courseRepository = courseRepository;
//    }

//    public Course createCourse(Course course) {
//        return courseRepository.save(course);
//    }

    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }
}


*/
    
    public Course addCourse(CourseDTO courseDTO) {
        // Map DTO to entity
        Course course = new Course();
        course.setTitle(courseDTO.getTitle());
        course.setDescription(courseDTO.getDescription());
        course.setInstructor(courseDTO.getInstructor());
        course.setStatus(1);
        course.setUserId(courseDTO.getUserId());

        // Save entity to database
        return courseRepository.save(course);
    }
    
    public List<Course> getAllCourses() {
        return courseRepository.findAll();
    }
    public Course getCourseById(Long id) {
        return courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with ID: " + id));
    }
    
    public Course updateCourse(Long id, CourseDTO courseDTO) {
        // Fetch the existing course
        Course existingCourse = courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found with ID: " + id));

        // Update the fields
        existingCourse.setTitle(courseDTO.getTitle());
        existingCourse.setDescription(courseDTO.getDescription());
        existingCourse.setInstructor(courseDTO.getInstructor());
        existingCourse.setStatus(courseDTO.getStatus());
        existingCourse.setUserId(courseDTO.getUserId());

        // Save and return the updated course
        return courseRepository.save(existingCourse);
    }
    
}
