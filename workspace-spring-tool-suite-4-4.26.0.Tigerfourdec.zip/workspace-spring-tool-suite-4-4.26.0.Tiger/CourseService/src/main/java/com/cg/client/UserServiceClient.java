package com.cg.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.config.FeignConfig;
import com.cg.dto.UserDTO;

//@FeignClient(name = "UserService", url = "http://localhost:8081/users")
//
//public interface UserServiceClient {
//	 @GetMapping("/{id}")
//	    UserDTO getUserById(@PathVariable("id") Long id);
//}


@FeignClient(name = "user-service", url = "http://localhost:8081")
public interface UserServiceClient {
    @GetMapping("/users/{id}")
    UserDTO getUserById(@PathVariable("id") Long id);
}
