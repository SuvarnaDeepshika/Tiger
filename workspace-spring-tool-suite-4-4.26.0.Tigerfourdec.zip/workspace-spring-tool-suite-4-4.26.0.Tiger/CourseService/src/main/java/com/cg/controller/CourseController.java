package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.CourseDTO;
import com.cg.entity.Course;
import com.cg.service.CourseService;

import jakarta.validation.Valid;

@RestController

public class CourseController {
	@Autowired
    private CourseService courseService;

	/*
	 * @PostMapping( "/addcourse") public ResponseEntity<Course>
	 * createCourse(@RequestBody CourseDTO courseDTO) { Course savedCourse =
	 * courseService.createCourse(courseDTO); return
	 * ResponseEntity.status(HttpStatus.CREATED).body(savedCourse); }
	 */
	
	@PostMapping("/addCourse")
    public ResponseEntity<Course> addCourse(@Valid @RequestBody CourseDTO courseDTO) {
        Course savedCourse = courseService.addCourse(courseDTO);
        return ResponseEntity.ok(savedCourse);
    }
    
	 @GetMapping("courses")
	    public ResponseEntity<List<Course>> getAllCourses() {
	        List<Course> courses = courseService.getAllCourses();
	        return ResponseEntity.ok(courses);
	    }
	 @GetMapping("/{id}")
	    public ResponseEntity<Course> getCourseById(@PathVariable Long id) {
	        Course course = courseService.getCourseById(id);
	        return ResponseEntity.ok(course);
	    }
	 @PutMapping("/{id}")
	    public ResponseEntity<Course> updateCourse(@PathVariable Long id, @Valid @RequestBody CourseDTO courseDTO) {
	        Course updatedCourse = courseService.updateCourse(id, courseDTO);
	        return ResponseEntity.ok(updatedCourse);
	    }
    
    
    
    
    
    
    
    
    
    
	
	/*
	 * public CourseController(CourseService courseService) { this.courseService =
	 * courseService; }
	 * 
	 * 
	 * // @PostMapping // public ResponseEntity<Course> createCourse(@RequestBody
	 * Course course) { // return
	 * ResponseEntity.ok(courseService.createCourse(course)); // }
	 * 
	 * @GetMapping public ResponseEntity<List<Course>> getCourses() { return
	 * ResponseEntity.ok(courseService.getAllCourses()); }
	 */

}
