package com.cg.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "course-service", url = "http://localhost:8082/api/courses") // Update URL as needed
public interface COurseServiceClient {
    @GetMapping("/{id}")
    Boolean doesCourseExist(@PathVariable("id") Long id);
}