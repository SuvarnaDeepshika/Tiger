package com.cg.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.client.COurseServiceClient;
import com.cg.client.UserServiceClient;
import com.cg.dto.EnrollmentDTO;
import com.cg.entity.Enrollment;
import com.cg.exception.ResourceNotFoundException;
import com.cg.repository.EnrollmentRepository;

@Service
public class EnrollmentService {
	
	

	    @Autowired
	    private EnrollmentRepository enrollmentRepository;

	    /**
	     * Create a new enrollment.
	     */
	    public Enrollment createEnrollment(Enrollment enrollment) {
	        return enrollmentRepository.save(enrollment);
	    }

	    /**
	     * Get all enrollments.
	     */
	    public List<Enrollment> getAllEnrollments() {
	        return enrollmentRepository.findAll();
	    }

	    /**
	     * Get an enrollment by ID.
	     */
	    public Enrollment getEnrollmentById(Long id) {
	        return enrollmentRepository.findById(id)
	                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found with ID: " + id));
	    }

	    /**
	     * Update enrollment status.
	     */
	    public Enrollment updateEnrollmentStatus(Long id, String status) {
	        Enrollment enrollment = getEnrollmentById(id);
	        enrollment.setStatus(2);
	        return enrollmentRepository.save(enrollment);
	    }

	    /**
	     * Delete an enrollment by ID.
	     */
	    public void deleteEnrollment(Long id) {
	        Enrollment enrollment = getEnrollmentById(id);
	        enrollmentRepository.delete(enrollment);
	    }
	}



