package com.cg.dto;

public class CourseDTO {
	    private Long id;
	    private String name;

}
