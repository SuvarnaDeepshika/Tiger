package com.cg.dto;

import lombok.Data;

@Data
public class EnrollmentDTO {
    private Long userId; // User ID
    private Long courseId; // Course ID
    private String status; // Enrollment Status
}