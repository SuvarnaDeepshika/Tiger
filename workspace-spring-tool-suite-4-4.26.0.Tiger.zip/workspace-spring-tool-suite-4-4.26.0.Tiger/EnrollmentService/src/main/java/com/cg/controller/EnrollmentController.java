package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.dto.EnrollmentRequestDTO;
import com.cg.dto.EnrollmentResponseDTO;
import com.cg.entity.Enrollment;
import com.cg.service.EnrollmentService;
import jakarta.validation.Valid;

@RestController
public class EnrollmentController { 

	 @Autowired
	    private EnrollmentService enrollmentService;

		/*
		 * @PostMapping("/enroll") public ResponseEntity<EnrollmentDTO>
		 * enrollUserToCourse(@RequestBody EnrollmentDTO enrollmentDTO) { EnrollmentDTO
		 * response = enrollmentService.enrollUserToCourse(enrollmentDTO); return
		 * ResponseEntity.status(HttpStatus.CREATED).body(response); }
		 */
	  @PostMapping("/enroll")
	    public ResponseEntity<EnrollmentResponseDTO> enrollUserToCourse(@RequestBody EnrollmentRequestDTO enrollmentRequestDTO) {
	        EnrollmentResponseDTO response = enrollmentService.enrollUserToCourse(enrollmentRequestDTO);
	        return ResponseEntity.status(HttpStatus.CREATED).body(response);
	    }
	 
}
	 
	
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 
	 

	  /*  @PostMapping
	    public ResponseEntity<Enrollment> createEnrollment(@RequestBody Enrollment enrollment) {
	        Enrollment createdEnrollment = enrollmentService.createEnrollment(enrollment);
	        return ResponseEntity.ok(createdEnrollment);
	    }

	   
	    @GetMapping
	    public ResponseEntity<List<Enrollment>> getAllEnrollments() {
	        List<Enrollment> enrollments = enrollmentService.getAllEnrollments();
	        return ResponseEntity.ok(enrollments);
	    }

	   
	    @GetMapping("/{id}")
	    public ResponseEntity<Enrollment> getEnrollmentById(@PathVariable Long id) {
	        Enrollment enrollment = enrollmentService.getEnrollmentById(id);
	        return ResponseEntity.ok(enrollment);
	    }

	   
	    @PutMapping("/{id}/status")
	    public ResponseEntity<Enrollment> updateEnrollmentStatus(@PathVariable Long id, @RequestParam String status) {
	        Enrollment updatedEnrollment = enrollmentService.updateEnrollmentStatus(id, status);
	        return ResponseEntity.ok(updatedEnrollment);
	    }

	    @DeleteMapping("/{id}")
	    public ResponseEntity<Void> deleteEnrollment(@PathVariable Long id) {
	        enrollmentService.deleteEnrollment(id);
	        return ResponseEntity.noContent().build();
	    }
	}*/