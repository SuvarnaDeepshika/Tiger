package com.cg.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.client.CourseServiceClient;
import com.cg.client.UserServiceClient;
import com.cg.dto.AccessToken;
import com.cg.dto.CourseDTO;
import com.cg.dto.EnrollmentRequestDTO;
import com.cg.dto.EnrollmentResponseDTO;
import com.cg.dto.UserDTO;
import com.cg.entity.Enrollment;
import com.cg.exception.ResourceNotFoundException;
import com.cg.repository.EnrollmentRepository;

@Service
public class EnrollmentService {
	@Autowired
    private EnrollmentRepository enrollmentRepository;

    @Autowired
    private UserServiceClient userServiceClient;  
    @Autowired
    private CourseServiceClient courseServiceClient;  

  
    public EnrollmentResponseDTO enrollUserToCourse(EnrollmentRequestDTO enrollmentRequestDTO) {
        // Step 1: Validate the access token via UserService
        AccessToken accessToken = new AccessToken();
        accessToken.setAccessToken(enrollmentRequestDTO.getAccessToken());  // Pass the token

        // Call UserService to validate the token
        ResponseEntity<UserDTO> userResponse = userServiceClient.validateAccessToken(accessToken);
        UserDTO userDTO = userResponse.getBody();
        
        if (userDTO == null) {
            throw new RuntimeException("Invalid access token!");
        }

        // Step 2: Fetch course details from CourseService
        ResponseEntity<CourseDTO> courseResponse = courseServiceClient.getCourseById(enrollmentRequestDTO.getCourseId());
        CourseDTO courseDTO = courseResponse.getBody();
        
        if (courseDTO == null) {
            throw new RuntimeException("Course not found!");
        }

        // Step 3: Create and save the enrollment entity
        Enrollment enrollment = new Enrollment();
        enrollment.setCreationTime(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")));
        enrollment.setStatus(1); // Active enrollment
        enrollment.setUserId(enrollmentRequestDTO.getUserId());
        enrollment.setCourseId(enrollmentRequestDTO.getCourseId());

        Enrollment savedEnrollment = enrollmentRepository.save(enrollment);

        // Step 4: Prepare response DTO
        EnrollmentResponseDTO response = new EnrollmentResponseDTO();
        response.setId(savedEnrollment.getId());
        response.setCreationTime(savedEnrollment.getCreationTime());
        response.setStatus(savedEnrollment.getStatus());
        response.setMessage("You have enrolled successfully!");

        return response;
    }
	}



