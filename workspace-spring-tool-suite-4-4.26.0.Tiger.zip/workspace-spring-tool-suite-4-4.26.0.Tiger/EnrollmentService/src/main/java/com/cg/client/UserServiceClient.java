package com.cg.client;


import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cg.dto.AccessToken;
import com.cg.dto.UserDTO;



/*
 * @FeignClient(name = "user-service", url = "http://localhost:8081/api/users")
 * // Update URL as needed public interface UserServiceClient {
 * 
 * @GetMapping("/{id}") Boolean doesUserExist(@PathVariable("id") Long id); }
 */


/*@FeignClient(name = "user-service", url = "http://localhost:8081/api/users")
public interface UserServiceClient {
    @PostMapping("/validateToken")
    ResponseEntity<UserDTO> validateAccessToken(@RequestBody AccessToken accessToken);
}*/
@FeignClient(name = "user-service", url = "http://localhost:8081")
public interface UserServiceClient {
    @PostMapping("/users/validateAccessToken")
    ResponseEntity<UserDTO> validateAccessToken(@RequestBody AccessToken accessToken);
}
