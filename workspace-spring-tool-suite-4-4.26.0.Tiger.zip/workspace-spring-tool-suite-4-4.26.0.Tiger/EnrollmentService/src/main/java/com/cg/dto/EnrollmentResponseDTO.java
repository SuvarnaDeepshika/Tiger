package com.cg.dto;

import lombok.Data;

@Data
public class EnrollmentResponseDTO {
    private Long id; // The ID of the enrollment record
    private String creationTime; // The time when the enrollment was created
    private int status; // The status of the enrollment (e.g., 1 for active)
    private String message; // A message indicating successful enrollment
}
