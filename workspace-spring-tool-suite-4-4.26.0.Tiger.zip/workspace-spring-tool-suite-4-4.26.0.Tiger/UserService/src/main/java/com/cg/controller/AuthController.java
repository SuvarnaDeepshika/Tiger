package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.AccessToken;
import com.cg.dto.UserDTO;
import com.cg.service.AuthService;

@RestController
@RequestMapping("/users")
public class AuthController {

    @Autowired
    private AuthService authService;

    @PostMapping("/validateAccessToken")
    public ResponseEntity<UserDTO> validateAccessToken(@RequestBody AccessToken accessToken) {
        // Validate the access token using AuthService
        boolean isValid = authService.validateAccessToken(accessToken.getAccessToken());
        
        if (isValid) {
            // Here you can return a UserDTO or whatever data is needed
            UserDTO userDTO = new UserDTO(); // You would populate this with actual user data
            return ResponseEntity.ok(userDTO);
        } else {
            return ResponseEntity.status(401).body(null); // Unauthorized if invalid
        }
    }
}