package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.Repository.AuthRepository;
import com.cg.entity.Auth;

@Service
public class AuthService {
	@Autowired
    private AuthRepository authRepository;

   public boolean validateAccessToken(String accessToken) {
       Auth auth = authRepository.findByAccessToken(accessToken);
       System.out.println("Auth retrieved: " + auth); // Log for debugging
       return auth != null && auth.getStatus() == 1; // Assuming '1' means active
   }
   
   public Auth getAuthByAccessToken(String accessToken) {
	    Auth auth = authRepository.findByAccessToken(accessToken);
	    if (auth == null || auth.getStatus() != 1) {
	        throw new RuntimeException("Invalid or expired access token");
	    }
	    return auth;
	}

   
   
   
   
}
