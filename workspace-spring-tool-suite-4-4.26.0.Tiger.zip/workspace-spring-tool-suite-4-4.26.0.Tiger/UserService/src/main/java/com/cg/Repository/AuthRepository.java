package com.cg.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.entity.Auth;
import com.cg.entity.User;

public interface AuthRepository extends JpaRepository<Auth, Long> {
	Auth findByAccessToken(String accessToken);
	void deleteByUser(User user);


}
