package com.cg.Repository;
import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.entity.Role;
public interface RoleRepository extends JpaRepository <Role, Long> {
	

}
