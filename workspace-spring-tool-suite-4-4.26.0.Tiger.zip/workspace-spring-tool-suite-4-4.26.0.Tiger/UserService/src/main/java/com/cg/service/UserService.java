package com.cg.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.cg.Repository.AuthRepository;
import com.cg.Repository.RoleRepository;
import com.cg.Repository.UserRepository;
import com.cg.dto.UserDTO;
import com.cg.entity.Auth;
import com.cg.entity.Role;
import com.cg.entity.User;
import com.cg.util.TokenUtils;

import jakarta.transaction.Transactional;



@Service
public class UserService {
	@Autowired
	private RoleRepository rolerepository;
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private AuthRepository authRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;

    public String registerUser(UserDTO userDTO) {
        // Create a new User entity
    	
    	if(userRepository.findByUsername(userDTO.getUsername()).isPresent())
    	{
    		throw new  RuntimeException("Username already exists");
    	}
    	
    	Role userRole =rolerepository.findById(2L).orElseThrow(() -> new RuntimeException("Role not found"));
        User user = new User();
        user.setFirstname(userDTO.getFirstname());
        user.setLastname(userDTO.getLastname());
        user.setUsername(userDTO.getUsername());
        //user.setPassword(userDTO.getPassword());
        user.setPassword(passwordEncoder.encode(userDTO.getPassword())); // Encode password here

       // user.setPassword(passwordEncoder.encode(userDTO.getPassword()));
       // user.setStatus(userDTO.getStatus());
        user.setStatus(1);
        user.setRole(userRole);
        // Set created time
        user.setCreatedTime(LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")));
        // Save user to the database
        userRepository.save(user);

        return "User registered successfully";
        
    }
    public String loginUser(UserDTO userDTO) {
        User user = userRepository.findByUsername(userDTO.getUsername())
            .orElseThrow(() -> new RuntimeException("User not found"));

        if (!passwordEncoder.matches(userDTO.getPassword(), user.getPassword())) {
            throw new RuntimeException("Invalid credentials");
        }

        Auth auth = new Auth();
        LocalDateTime loginTime = LocalDateTime.now();
        String formattedLoginTime = loginTime.format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);

        auth.setLogintime(formattedLoginTime);
        auth.setStatus(1);
       // auth.setAccessToken("generated-token"); // Replace with your token logic if needed
        auth.setAccessToken(TokenUtils.generateAccessToken()); // Replace with your token logic if needed

        auth.setUser(user);

        authRepository.save(auth);
        return auth.getAccessToken();
    }
    
    public UserDTO getUserProfile(String username) {
        // Find the user in the database
        User user = userRepository.findByUsername(username)
            .orElseThrow(() -> new RuntimeException("User not found"));

        // Map User entity to UserDTO
        UserDTO userDTO = new UserDTO();
        userDTO.setFirstname(user.getFirstname());
        userDTO.setLastname(user.getLastname());
        userDTO.setUsername(user.getUsername());
        userDTO.setStatus(user.getStatus());
        userDTO.setRole(user.getRole().getName()); 
        return userDTO;
    }

	    public List<UserDTO> getAllUsers() {
        List<UserDTO> userList = userRepository.findAll().stream().map(user -> {
            UserDTO dto = new UserDTO();
            dto.setFirstname(user.getFirstname());
            dto.setLastname(user.getLastname());
            dto.setUsername(user.getUsername());
            dto.setStatus(user.getStatus());
            dto.setRole(user.getRole().getName());
            return dto;
        }).collect(Collectors.toList());
        System.out.println("Fetched Users: " + userList); // Debugging
        return userList;
	 }
	    
	  @Transactional
	    public void deleteUser(String username) {
	        // Fetch user by username
	        User user = userRepository.findByUsername(username)
	            .orElseThrow(() -> new RuntimeException("User not found"));

	        // Delete related auth records manually
	        authRepository.deleteByUser(user);

	        // Delete the user
	        userRepository.delete(user);
	    }

	    
	



}
