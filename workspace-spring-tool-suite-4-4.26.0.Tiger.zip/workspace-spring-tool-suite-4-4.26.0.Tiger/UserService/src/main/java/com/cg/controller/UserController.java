package com.cg.controller;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.cg.Repository.AuthRepository;
import com.cg.Repository.UserRepository;
import com.cg.dto.AccessToken;
import com.cg.dto.UserDTO;
import com.cg.entity.Auth;
import com.cg.entity.User;
import com.cg.service.AuthService;
import com.cg.service.UserService;

import jakarta.persistence.Cacheable;

@RestController
@RequestMapping("/users")
public class UserController {
	@Autowired
    private UserService userService;
	@Autowired
	private UserRepository userRepository;
	@Autowired
    private AuthService authService;
	@Autowired
    private AuthRepository authRepository;

    @PostMapping("/register")
    public ResponseEntity<String> registerUser(@RequestBody UserDTO userDTO) {
        String message = userService.registerUser(userDTO);
        return ResponseEntity.ok(message);
    }
    
    @PostMapping("/login")
    public ResponseEntity<String> loginUser(@RequestBody UserDTO userDTO) {
        try {
            String accessToken = userService.loginUser(userDTO);
            return ResponseEntity.ok(accessToken);
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body("Invalid credentials");
        }
    }
    
 
    @PostMapping("/getAllUsers")
    public ResponseEntity<List<UserDTO>> getAllUsers(@RequestBody AccessToken accessToken) {
        System.out.println("getAllUsers API called with accessToken: " + accessToken.getAccessToken());
        if (!authService.validateAccessToken(accessToken.getAccessToken())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build(); // 401 Unauthorized
        }

        // Fetch all users
        List<User> users = userRepository.findAll();

        // Map User to UserDTO
        List<UserDTO> userDTOs = users.stream().map(user -> {
            UserDTO dto = new UserDTO();
            dto.setFirstname(user.getFirstname());
            dto.setLastname(user.getLastname());
            dto.setUsername(user.getUsername());
            dto.setStatus(user.getStatus());
            dto.setRole(user.getRole().getName()); // Assuming Role has a 'name' property
            return dto;
        }).collect(Collectors.toList());

        return ResponseEntity.ok(userDTOs);
    }
    
    
    @PostMapping("/getByUserId")
    public ResponseEntity<?> getUserByAccessToken(@RequestBody AccessToken accessToken) {
        // Validate access token
        if (!authService.validateAccessToken(accessToken.getAccessToken())) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Authentication failed: Invalid or expired access token");
        }

        // Fetch the Auth entity using the access token
        Auth auth = authRepository.findByAccessToken(accessToken.getAccessToken());
        if (auth == null) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
                    .body("Authentication failed: No user associated with this token");
        }

        // Retrieve the associated user
        User user = auth.getUser();

        // Map User to UserDTO
        UserDTO userDTO = new UserDTO();
        userDTO.setFirstname(user.getFirstname());
        userDTO.setLastname(user.getLastname());
        userDTO.setUsername(user.getUsername());
        userDTO.setPassword(null); // Mask password for security
        userDTO.setStatus(user.getStatus());
        userDTO.setRole(user.getRole().getName()); // Assuming Role has a 'name' property

        // Return success response
     // Return success response
        return ResponseEntity.ok(userDTO);
    }
    }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
 
    
//    @GetMapping("/users")
//    public ResponseEntity<List<UserDTO>> getAllUsers() {
//        List<UserDTO> users = userService.getAllUsers();
//        if (users.isEmpty()) {
//            return ResponseEntity.noContent().build(); // Respond with 204 No Content
//        }
//        return ResponseEntity.ok(users);
//    }
//    
//    @GetMapping("/users/{username}")
//    public ResponseEntity<UserDTO> getUserByUsername(@PathVariable String username) {
//        try {
//            // Fetch user details from the service layer
//            UserDTO userDTO = userService.getUserProfile(username);
//            return ResponseEntity.ok(userDTO);
//        } catch (RuntimeException e) {
//            // Return 404 if user not found
//            return ResponseEntity.status(404).body(null);
//        }
//    }
//    
//    @DeleteMapping("/users/{username}")
//    public ResponseEntity<String> deleteUser(@PathVariable String username) {
//        try {
//            userService.deleteUser(username);  // Call service to delete the user
//            return ResponseEntity.ok("User deleted successfully");
//        } catch (RuntimeException e) {
//            return ResponseEntity.status(400).body("Error deleting user: " + e.getMessage());
//        }
//    }
	

