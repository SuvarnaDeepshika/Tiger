package com.cg.util;

import java.util.UUID;

public class TokenUtils {
	public static String  generateAccessToken() {
		return UUID.randomUUID().toString();
				}

}
