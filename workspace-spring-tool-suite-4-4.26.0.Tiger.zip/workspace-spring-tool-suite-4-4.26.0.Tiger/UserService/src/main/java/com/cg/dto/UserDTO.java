package com.cg.dto;

import com.cg.entity.User;

import lombok.Data;

@Data
public class UserDTO {
    private String firstname;
    private String lastname;
    private String username;
    private String password;
    private int status;
    private String role;
    
    public UserDTO(User user) {
        this.username = user.getUsername();
        this.firstname = user.getFirstname();
        this.lastname = user.getLastname();
    }

	public UserDTO() {
		super();
	}
    
}




