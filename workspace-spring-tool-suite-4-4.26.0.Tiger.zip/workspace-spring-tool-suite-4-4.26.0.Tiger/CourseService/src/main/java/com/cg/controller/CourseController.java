package com.cg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dto.CourseDTO;
import com.cg.entity.Course;
import com.cg.exception.ResourceNotFoundException;
import com.cg.service.AuthService;
import com.cg.service.CourseService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/courses")

public class CourseController {
	@Autowired
	private CourseService courseService;
	@Autowired
	private AuthService authService;

	
	 @PostMapping("/addCourse")
	    public ResponseEntity<CourseDTO> addCourse(@RequestBody CourseDTO courseDTO) {
	        CourseDTO createdCourse = courseService.addCourse(courseDTO);
	        return ResponseEntity.status(HttpStatus.CREATED).body(createdCourse);
	    }
	 
	 @PostMapping("/getAllCourses")
	    public ResponseEntity<List<CourseDTO>> getAllCourses(@RequestBody CourseDTO courseDTO) {
	        try {
	            // Validate and fetch all courses
	            List<CourseDTO> courses = courseService.getAllCourses(courseDTO.getAccessToken());
	            return ResponseEntity.ok(courses);
	        } catch (RuntimeException e) {
	            // Handle errors such as invalid access token
	            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null);
	        } catch (Exception e) {
	            // Catch-all for unexpected exceptions
	            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
	        }
	    }
	 @PostMapping("/getById")
	 public ResponseEntity<CourseDTO> getCourseById(@RequestBody CourseDTO request) {
	     try {
	         CourseDTO courseDTO = courseService.getCourseById(request.getId(), request.getAccessToken());
	         return ResponseEntity.ok(courseDTO);
	     } catch (ResourceNotFoundException e) {
	         return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null); // Course not found
	     } catch (RuntimeException e) {
	         return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(null); // Invalid access token
	     } catch (Exception e) {
	         return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null); // Unexpected error
	     }
	 }

}
