package com.cg.dto;


import lombok.Data;

@Data
public class AccessToken {
	private String accessToken;

}
