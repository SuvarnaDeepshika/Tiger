package com.cg.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.cg.Repository.AuthRepository;
import com.cg.Repository.UserRepository;
import com.cg.client.UserServiceClient;
import com.cg.dto.CourseDTO;
import com.cg.dto.UserDTO;
import com.cg.entity.Auth;
import com.cg.entity.Course;
import com.cg.entity.User;
import com.cg.exception.ResourceNotFoundException;
import com.cg.repository.CourseRepository;

import feign.FeignException;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;

@Service

public class CourseService {
	@Autowired
    private CourseRepository courseRepository;

    @Autowired
    private AuthRepository authRepository;

    @Autowired
    private UserRepository userRepository;
    
    @Autowired 
    private UserServiceClient userServiceClient;
    
    @Autowired
    private AuthService authService;
    
    @Transactional
    public CourseDTO addCourse(CourseDTO courseDTO) {
        // Step 1: Validate the access token using AuthService
        boolean isValid = authService.validateAccessToken(courseDTO.getAccessToken());
        if (!isValid) {
            throw new RuntimeException("Invalid or expired access token");
        }

        // Step 2: Fetch the userId from the Auth entity
        Auth auth = authService.getAuthByAccessToken(courseDTO.getAccessToken());
        Long userId = auth.getUser().getId();

        // Step 3: Save course details to the database
        Course course = new Course();
        course.setTitle(courseDTO.getTitle());
        course.setDescription(courseDTO.getDescription());
        course.setInstructor(courseDTO.getInstructor());
        course.setUserId(userId);
        course.setStatus(1); // Default status

        Course savedCourse = courseRepository.save(course);

        // Step 4: Prepare the response DTO
        CourseDTO response = new CourseDTO();
        response.setTitle(savedCourse.getTitle());
        response.setDescription(savedCourse.getDescription());
        response.setInstructor(savedCourse.getInstructor());
        response.setStatus(savedCourse.getStatus());
        response.setUserId(savedCourse.getUserId());
//        response.setAccessToken(courseDTO.getAccessToken()); // Echo the token

        return response;
    }
    
    @Transactional
    public List<CourseDTO> getAllCourses(String accessToken) {
        // Step 1: Validate the access token
        boolean isValid = authService.validateAccessToken(accessToken);
        if (!isValid) {
            throw new RuntimeException("Invalid or expired access token");
        }

        // Step 2: Fetch all courses from the database
        List<Course> courses = courseRepository.findAll();

        // Step 3: Map Course entities to CourseDTO responses
        return courses.stream().map(course -> {
            CourseDTO courseDTO = new CourseDTO();
            courseDTO.setTitle(course.getTitle());
            courseDTO.setDescription(course.getDescription());
            courseDTO.setInstructor(course.getInstructor());
            courseDTO.setStatus(course.getStatus());
            courseDTO.setUserId(course.getUserId());
           // courseDTO.setAccessToken(accessToken); // Echo the token
            return courseDTO;
        }).collect(Collectors.toList());
    }

}
