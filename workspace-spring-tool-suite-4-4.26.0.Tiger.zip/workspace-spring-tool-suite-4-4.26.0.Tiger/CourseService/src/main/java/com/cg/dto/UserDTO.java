package com.cg.dto;

import lombok.Data;

@Data
public class UserDTO {
    private String firstname;
    private String lastname;
    private String username;
    private int status;
    private String role;
    private int userid;
}
